ERA5 data from 1940-01-01 to 2025-12-31 for Bristol, United Kingdom (51.42355 ˚N,-2.6039734 ˚E).

Time zone is Europe/London,GMT.

Columns are date. temperature_2m_mean (°C), precipitation_sum (mm).

Downloaded from Open Meteo: https://open-meteo.com/en/docs/historical-weather-api.

For the exercise, the full record is split up into months, structured into directories according to `YYYY/MM/YYYY-MM.csv`.